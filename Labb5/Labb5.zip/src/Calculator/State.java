package Calculator;

enum State {
   Input1,
   OpReady,
   Input2,
   HasResult
}
